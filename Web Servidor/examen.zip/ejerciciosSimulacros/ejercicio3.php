<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <title>Nuevos Usuarios</title>
</head>
<body>
<div class="container mt-5">
    <?php

    include 'codigoejercicio3.php';

    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<tr>';
    echo '<th scope="col">Nombre</th>';
    echo '<th scope="col">Email</th>';
    echo '<th scope="col">Contraseña</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if ($_POST['action'] === 'add') {
            $name = $_POST['name'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            if (strpos($email, '@') !== false && strlen($password) >= 8) {
                añadirUsuario($name, $email, $password);
            } else {
                echo '<div class="alert alert-danger mt-3" role="alert">';
                echo 'Pon un email que sirva (que tenga @) y la contraseña al menos 8 caracteres.';
                echo '</div>';
            }
        }
    }

    echo '<h2 class="mt-5 mb-3">Agregar Nuevo Usuario</h2>';
    echo '<form method="post" action="ejercicio3.php">';
    echo '<input type="hidden" name="action" value="add">';
    echo '<div class="form-group">';
    echo '<label for="name">Nombre:</label>';
    echo '<input type="text" class="form-control" name="name" required>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="email">Email:</label>';
    echo '<input type="text" class="form-control" name="email" required>';
    echo '</div>';
    echo '<div class="form-group">';
    echo '<label for="password">Contraseña:</label>';
    echo '<input type="text" class="form-control" name="password" required>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Agregar Usuario</button>';
    echo '</form>';
    ?>

</body>
</html>
