<?php

class monedero {

    public $monedero = 100;
    public $cantidadMorosa;
    public $ingresos;

    public function contructor ($monedero){
        $this->monedero = $monedero;
    }


    public function pagar_con_monedero ($monedero, $cantidadMorosa){
        if($monedero < $cantidadMorosa){
            echo "No hay suficiente dinero, eres pobre.";
        }else{
        echo "Lo que te queda de dinero es: " . ($this -> monedero - $this -> cantidadMorosa);
        }
    }
    
    public function incrementa_monedero ($monedero, $ingresos){
        echo "Ahora tienes: " . ($this -> monedero + $this -> ingresos) . " de dinero, enhorabuena, dejas de ser pobre.";
    }

}


?>