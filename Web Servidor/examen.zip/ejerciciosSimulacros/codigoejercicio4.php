<?php
session_start();

if (!isset($_SESSION['libros'])) {
    $_SESSION['libros'] = array();
}
function agregar_libro($titulo, $autor, $genero) {
    $libros = $_SESSION['libros'];
    $libro = array('titulo' => $titulo, 'autor' => $autor, 'genero' => $genero);
    $libros[] = $libro;

    $_SESSION['libros'] = $libros;
}
function mostrar_libro() {
    $libros = $_SESSION['libros'];

    if (!empty($libros)) {
        echo '<h2>Libros Registrados</h2>';
        echo '<table border="1">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Título</th>';
        echo '<th>Autor</th>';
        echo '<th>Género</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        foreach ($libros as $libro) {
            echo '<tr>';
            echo '<td>' . $libro['titulo'] . '</td>';
            echo '<td>' . $libro['autor'] . '</td>';
            echo '<td>' . $libro['genero'] . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No hay libros registrados.</p>';
    }
}

function buscar_libro($tituloBuscado) {
    $libros = $_SESSION['libros'];
    foreach ($libros as $libro) {
        if (strcasecmp($libro['titulo'], $tituloBuscado) === 0) {
            return $libro;
        }
    }
    return null; 
}
?>
