<?php

function añadirUsuario($name, $email, $password) {
    echo '<tr>';
    echo '<td>' . $name . '</td>';
    echo '<td>' . $email . '</td>';
    echo '<td>' . $password . '</td>';
    echo '</tr>';
}

?>
