<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Libros</title>
</head>
<body>
<?php

    include 'codigoejercicio4.php';
    mostrar_libro();
    
?>

<div>
    <div>
        <form action="codigoejercicio4.php" method="post">
            <h2>Agregar Libro</h2>
            <div>
                <label for="titulo">Título:</label>
                <input type="text" id="titulo" name="titulo" required>
            </div>
            <div>
                <label for="autor">Autor:</label>
                <input type="text" id="autor" name="autor" required>
            </div>
            <div>
                <label for="genero">Género:</label>
                <input type="text" id="genero" name="genero" required>
            </div>
            <button type="submit" name="agregar_libro">Agregar Libro</button>
        </form>
    </div>

    <div>
        <form action="codigoejercicio4.php" method="get">
            <h2>Buscar Libro</h2>
            <div>
                <label for="buscarTitulo">Buscar por Título:</label>
                <input type="text" id="buscarTitulo" name="buscarTitulo" required>
            </div>
            <button type="submit" name="buscar">Buscar Libro</button>
        </form>
    </div>
</div>

</body>
</html>
