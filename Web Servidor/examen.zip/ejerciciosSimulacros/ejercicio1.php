<?php

class conector_db {

    public $servidor = "localhost";
    public $usuario = "root";
    public $password = "";
    public $baseDeDatos = "nombreDeTuBaseDeDatos";
    
    /* constructor que pide para conectar*/
    public function constructor($servidor, $usuario, $password, $baseDeDatos){
        $this->conexion = new mysqli($this->host, $this->usuario, $this->password,$this->baseDeDatos)
        or die($this->conexion->connect_error);
        $this->conexion->set_charset("utf8");
    }

     /* Apartado uno: metodo consulta */
    public function consultar($consulta){
        $resultado = $this->conexion->query( "SELECT id, campoABuscar FROM nombreTabla where id=PRIMARY KEY") or die($this->conexion->error);
        if($resultado)
             return $resultado;
     } 
     /* Apartado dos: metodo actualizar */
    public function actualizar($actualizar){
        $resultado = $this->conexion->query("INSERT INTO nombreTabla (id, nombre) VALUES ('{$id}','{$nombre}')") or die($this->conexion->error);
        if($resultado)
             return $resultado;
    }

    /* Apartado tres: metodo borrar */
    public function borrar($borrar){
        $borrar = $this->conexion->query("DELETE nombreCampo FROM nombreTabla WHERE nombreCampo= PRIMARY KEY") or die($this->conexion->error);
        if($borrar)
             return $borrar;
    }
}











?>