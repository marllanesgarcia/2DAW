<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="monkey.css">
    <title>Monkey Island</title>
</head>
<body>
    <h2> ¡Bienvenido a Monkey Island 🏝️!</h2>
    <div>
        <form method="post" action="funcionesUsuario.php">
            <label for="nombre">¡Escribe tu nombre de pirata!</label></br>
            <input type="text" name="nombre" id="nombre" required><br><br>
            <input type="submit" value="¡Comienza tu aventura!">
        </form>
    </div>
    <div>
    
    
    </div>



</body>
</html>