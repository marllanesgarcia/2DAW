<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monkey Island</title>
</head>
<body>
    <h1>¡Bienvenidos a las adivinanzas para ser un pirata!🏴‍☠️ </h1>
   
    <div>
        <?php include 'funcionesAdivinanzas.php'; ?>
    </div> 
</body>
</html>


</body>
</html>